﻿import time
import random
import datetime
import yaml
from prometheus_client import start_http_server, Gauge

# --- KHAI BÁO PROMETHEUS METRICS ---
CPU_USAGE = Gauge('bank_router_cpu_usage_percent', 'CPU Usage percentage', ['router', 'role'])
RAM_USAGE = Gauge('bank_router_ram_usage_percent', 'RAM Usage percentage', ['router', 'role'])
WAN_THROUGHPUT = Gauge('bank_wan_throughput_mbps', 'WAN Bandwidth Throughput Mbps', ['router', 'interface'])
LATENCY = Gauge('bank_wan_latency_ms', 'Ping Latency to Core Server in ms', ['router'])
LINK_STATUS = Gauge('bank_link_status', 'WAN Link Status (1=Up, 0=Down)', ['router', 'interface'])
HSRP_STATE = Gauge('bank_hsrp_state', 'HSRP Router State (1=Active, 0=Standby)', ['router', 'group'])
OSPF_NEIGHBOR_STATE = Gauge('bank_ospf_neighbor_state', 'OSPF Neighbor Status (1=Full, 0=Down)', ['router', 'neighbor'])

# --- ĐỌC CẤU HÌNH GROUND TRUTH TỪ TOPOLOGY.YAML ---
def load_topology():
    try:
        with open('topology.yaml', 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except Exception as e:
        print(f"Lỗi khi đọc file topology.yaml: {e}")
        return None

# Cấu hình giả lập sự cố (Dùng khi Demo kịch bản)
FAULT_SIMULATION = {
    "br_hcm_primary_down": False,  # Ngắt link WAN chính Branch HCM
    "br_bd_overload": False,        # Quá tải băng thông / Latency Branch BD
}

def is_peak_hours():
    """Kiểm tra xem có phải giờ làm việc hành chính của ngân hàng không (8h-11h30 & 13h-17h)"""
    now = datetime.datetime.now().time()
    morning_peak = datetime.time(8, 0) <= now <= datetime.time(11, 30)
    afternoon_peak = datetime.time(13, 0) <= now <= datetime.time(17, 0)
    return morning_peak or afternoon_peak

def generate_telemetry_metrics(topo):
    if not topo:
        return

    peak = is_peak_hours()
    
    # Lấy hệ số lưu lượng dựa trên giờ làm việc
    traffic_factor = 2.5 if peak else 0.8

    # 1. TRẠNG THÁI CORE ROUTER (HQ-CORE-RTR01)
    CPU_USAGE.labels(router="HQ-CORE-RTR01", role="Core").set(random.uniform(25, 45) * (1.2 if peak else 1.0))
    RAM_USAGE.labels(router="HQ-CORE-RTR01", role="Core").set(random.uniform(50, 60))
    LINK_STATUS.labels(router="HQ-CORE-RTR01", interface="Se0/3/0").set(0 if FAULT_SIMULATION["br_hcm_primary_down"] else 1)
    LINK_STATUS.labels(router="HQ-CORE-RTR01", interface="Se0/3/1").set(1)
    LINK_STATUS.labels(router="HQ-CORE-RTR01", interface="Se0/2/0").set(1)

    # 2. TRẠNG THÁI CHI NHÁNH HCM (HA CLUSTER)
    if FAULT_SIMULATION["br_hcm_primary_down"]:
        # Router 1 Primary gặp sự cố ngắt link
        LINK_STATUS.labels(router="BR-HCM-RTR01", interface="Se0/3/0").set(0)
        HSRP_STATE.labels(router="BR-HCM-RTR01", group="30").set(0) # Chuyển Standby
        HSRP_STATE.labels(router="BR-HCM-RTR02", group="30").set(1) # Backup nhảy lên Active
        OSPF_NEIGHBOR_STATE.labels(router="BR-HCM-RTR01", neighbor="HQ-CORE").set(0)
        OSPF_NEIGHBOR_STATE.labels(router="BR-HCM-RTR02", neighbor="HQ-CORE").set(1)
        
        LATENCY.labels(router="BR-HCM-RTR01").set(999) # Timeout
        LATENCY.labels(router="BR-HCM-RTR02").set(random.uniform(15, 25))
        WAN_THROUGHPUT.labels(router="BR-HCM-RTR01", interface="Se0/3/0").set(0.0)
        WAN_THROUGHPUT.labels(router="BR-HCM-RTR02", interface="Se0/3/0").set(random.uniform(3.0, 7.5) * traffic_factor)
    else:
        # Trạng thái bình thường: RTR01 là Master Active
        LINK_STATUS.labels(router="BR-HCM-RTR01", interface="Se0/3/0").set(1)
        LINK_STATUS.labels(router="BR-HCM-RTR02", interface="Se0/3/0").set(1)
        HSRP_STATE.labels(router="BR-HCM-RTR01", group="30").set(1) # Active
        HSRP_STATE.labels(router="BR-HCM-RTR02", group="30").set(0) # Standby
        OSPF_NEIGHBOR_STATE.labels(router="BR-HCM-RTR01", neighbor="HQ-CORE").set(1)
        OSPF_NEIGHBOR_STATE.labels(router="BR-HCM-RTR02", neighbor="HQ-CORE").set(1)
        
        CPU_USAGE.labels(router="BR-HCM-RTR01", role="HA-Master").set(random.uniform(20, 35))
        CPU_USAGE.labels(router="BR-HCM-RTR02", role="HA-Standby").set(random.uniform(10, 18))
        RAM_USAGE.labels(router="BR-HCM-RTR01", role="HA-Master").set(random.uniform(40, 52))
        RAM_USAGE.labels(router="BR-HCM-RTR02", role="HA-Standby").set(random.uniform(35, 42))
        
        LATENCY.labels(router="BR-HCM-RTR01").set(random.uniform(5, 12))
        LATENCY.labels(router="BR-HCM-RTR02").set(random.uniform(6, 14))
        WAN_THROUGHPUT.labels(router="BR-HCM-RTR01", interface="Se0/3/0").set(random.uniform(2.1, 3.8) * traffic_factor)
        WAN_THROUGHPUT.labels(router="BR-HCM-RTR02", interface="Se0/3/0").set(random.uniform(0.1, 0.5))

    # 3. TRẠNG THÁI CHI NHÁNH BÌNH DƯƠNG (BR-BD-RTR01)
    LINK_STATUS.labels(router="BR-BD-RTR01", interface="Se0/3/0").set(1)
    OSPF_NEIGHBOR_STATE.labels(router="BR-BD-RTR01", neighbor="HQ-CORE").set(1)
    
    if FAULT_SIMULATION["br_bd_overload"]:
        # Mô phỏng quá tải nghẽn mạng
        CPU_USAGE.labels(router="BR-BD-RTR01", role="Single-Router").set(random.uniform(88, 97))
        RAM_USAGE.labels(router="BR-BD-RTR01", role="Single-Router").set(random.uniform(82, 91))
        WAN_THROUGHPUT.labels(router="BR-BD-RTR01", interface="Se0/3/0").set(random.uniform(8.8, 9.8)) # Vượt 80% gói 10Mbps
        LATENCY.labels(router="BR-BD-RTR01").set(random.uniform(180, 320)) # Latency vọt cao
    else:
        # Bình thường
        CPU_USAGE.labels(router="BR-BD-RTR01", role="Single-Router").set(random.uniform(15, 30))
        RAM_USAGE.labels(router="BR-BD-RTR01", role="Single-Router").set(random.uniform(38, 48))
        WAN_THROUGHPUT.labels(router="BR-BD-RTR01", interface="Se0/3/0").set(random.uniform(1.0, 2.5) * traffic_factor)
        LATENCY.labels(router="BR-BD-RTR01").set(random.uniform(8, 16))

if __name__ == '__main__':
    topo_data = load_topology()
    if not topo_data:
        print("Không thể khởi chạy Exporter do thiếu dữ liệu topology!")
        exit(1)

    start_http_server(8000)
    print("=" * 60)
    print(" Bank Network Telemetry Exporter Running on Port :8000")
    print(" Reading Ground Truth from: topology.yaml")
    print("=" * 60)

    while True:
        generate_telemetry_metrics(topo_data)
        time.sleep(5)